# VoiceGPT

talking to AI in voice, learn speaking a second language from chatGPT

https://gptvoice.vercel.app/

<img width="885" alt="image" src="https://user-images.githubusercontent.com/23436060/228512131-6ccbc280-4d01-4717-a007-5cbc872b1aed.png">

## Known Issues

- Brave Browser won't work since it doesn't allow users to use voice input.

- no sound on some mobile browsers, please click the fix button to fix it before using.

## Looking for maintainer

create an issue and tell me what you want to do to improve this project.
