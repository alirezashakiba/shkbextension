// FIXME: Update this configuration file based on your project information

export const AppConfig = {
  site_name: 'VoiceGPT',
  title: 'VoiceGPT',
  description:
    'talking to AI in voice, learn speaking a second language from chatGPT',
  locale: 'en',
};
