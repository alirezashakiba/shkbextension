declare global {
  interface Window {}
}

export {};
